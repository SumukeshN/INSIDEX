from tkinter import *
from PIL import Image,ImageTk,ImageSequence
import time
root=Tk()
root.geometry("600x400")
def play_gif():
    img=Image.open("gif.gif")
    lbl=Label(root)
    lbl.place(x=0,y=0)
    for img in ImageSequence.Iterator(img):
        img=img.resize((600,400))
        img=ImageTk.PhotoImage(img)
        lbl.config(image=img)
        root.update()
        time.sleep(0.01)
play_gif()
root.mainloop()
